from flask_sqlalchemy import SQLAlchemy
from helpers.application import app
from flask_migrate import Migrate

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:emmanuel1@localhost:5432/cbodb' 

db = SQLAlchemy(app) #iniciando sqlAlchemy
migrate = Migrate(app, db) #uniciando migrate com app e db
import pandas as pd
import psycopg2

def csvParaPostgresPorRegiao(csv_file, db_params, table_name, cols, regiao_nome='Norte'):
    try:
        print(f"Iniciando importação para a região {regiao_nome}...")

        conn = psycopg2.connect(**db_params)
        cursor = conn.cursor()

        for chunk in pd.read_csv(csv_file, sep=";", encoding="ISO-8859-1", usecols=cols, chunksize=chunksize):
            # Filtra a região desejada
            chunk = chunk[chunk["NO_REGIAO"] == regiao_nome]



csvParaPostgresPorRegiao(
    csv_file="microdados_ed_basica_2023.csv",
    table_name="tb_instituicoes",
)